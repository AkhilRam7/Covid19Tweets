from flask import Flask, jsonify, request
import whisper

app = Flask(__name__)

model = whisper.load_model("base")

@app.route('/transcribe', methods=['POST'])
def predict():
    try:
        input_data = request.get_json()["filename"]
        predictions = model.transcribe(input_data)["text"]
        result = {'predictions': predictions}
        return jsonify(result)
    except Exception as e:
        print(e)
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)


