import requests
import json
import random
import time 
import pandas as pd

import streamlit as st
from streamlit_extras.stylable_container import stylable_container

from langchain.prompts import PromptTemplate
from langchain.chat_models import ChatOpenAI
from audio_recorder_streamlit import audio_recorder


pkey = "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"

price_prompt = PromptTemplate(
    input_variables = ["question"], template = """
    Instructions:

    Answer the question in a respective format based on the context below. If the question cannot be answered using the information provided answer with "0" within the below specified format.
    Please recheck the output's format and attribute value before answering, strictly follow the format

    Answer Format: ['Amount: integer', 'Quantity': integer"]
        
    Context: You are an assitant who tries to answer from financial perspective by extracting relavant information within the question sentence. You job is to identify
    quantity and amount mentioned in the user question. If you are unable to identify the relevant information answer with "0" for the fields mentioned in the format.
    
    Question: {question}

    Please understand on how to answer from below examples

    Example 1:
      Question: I am looking to place a limit order for hundred shares of Amazon, aiming to purchase them at a price not exceeding $3,000 per share.
      Answer: [Amount': 3000', "Quantity': 100']
      
    Example 2:
      Question: Placing a market order to sell 200 Apple shares immediately, regardless of the current market price.
      Answer: ['Amount': '0', 'Quantity': '200"]
    
    Example 3:
      Question: I'd like to initiate a limit order for 50 Google stocks, specifying a buying price of $2,500 per share.
      Answer: ['Amount': 2500', Quantity': '50']
    
    Example 4:
      Question: Selling 500 Microsoft shares using a market order to ensure a quick execution of the sell order.
      Answer: ['Amount': '0', 'Quantity": 500']
    
    Example 5:
      Question: I want to buy 150 Tesla shares with a limit order, setting a purchase price of seven hundred per share.
      Answer: ['Amount':'700', 'Quantity':150']
    
    Example 6:
      Question: Placing a market order to sell 300 Facebook shares promptly, without specifying a particular selling price.
      Answer: ['Amount:'0', 'Quantity': '300']
    
    Example 7:
      Question: Interested in purchasing 1,000 Nvidia shares at the current market price, executing the order immediately.
      Answer: ['Amount': '0', "Quantity': '1000']
    
    Example 8:
      Question: I am initiating a limit order to sell 75 Netflix shares, specifying a. selling price of $550 per share.
      Answer: ['Amount': '550', 'Quantity': '75']
    
    Example 9:
      Question: Buying 200 Amazon shares with a market order, prioritizing a swift execution of the purchase.
      Answer: [ Amount": 'O', 'Quantity': '200']
    
    Example 10:
      Question: I want to place a limit order for 120 Intel shares, aiming to buy them at a price not exceeding $50 per share.
      Answer: ['Amount': 50', 'Quantity': '120']
    
    Example 11:
      Question: Placing a market order to sell 400 IBM shares promptly, without setting a specific selling price.
      Answer: ['Amount': '0', 'Quantity': '400']
    
    Example 12:
      Question: I'd like to buy 80 Apple shares using a limit order, setting a purchase price of $150 per share.
      Answer: ['Amount': '150', 'Quantity': '80']
    
    Example 13:
      Question: Selling 250 Facebook shares with a market order, ensuring a quick execution of the sell order.
      Answer: ['Amount': '0', 'Quantity': 2'50']
    
    Example 14:
      Question: I am interested in purchasing 300 Google stocks at the current market price, executing the order immediately.
      Answer: ['Amount': '0', 'Quantity': '300']
    
    Example 15:
      Question: Placing a limit order to sell 50 Microsoft shares, specifying a selling price of $250 per share.
      Answer: ['Amount': '250', 'Quantity': '50']
    
    Example 16:
      Question: I want to place a market order to buy 100 Netflix shares promptly, without specifying a particular buying price.
      Answer: ['Amount': '0', 'Quantity':'100']
    
    Example 17:
      Question: Buying 150 Tesla shares with a limit order, setting a purchase price of $800 per share.
      Answer: ['Amount': '800', 'Quantity': '150']
    
    Example 18:
      Question: Initiating a market order to sell 200 Nvidia shares immediately, regardless of the current market price.
      Answer: ['Amount': '0', 'Quantity': '200']
    
    Example 19:
      Question: I am looking to place a limit order for 80 Amazon shares, aiming to purchase them at a price not exceeding $3,500 per share.
      Answer: ['Amount': '3500', "Quantity': '80']
    
    Example 20:
      Question: Placing a market order to sell 120 Intel shares promptfy, without setting a specific selling price.
      Answer: [Amount': '0', 'Quantity': '120']
    
    Example 21:
      Question: Selling 300 Apple shares using a market order to ensure a quick execution of the sell order.
      Answer: ['Amount': '0', 'Quantity': '300']
    
    Example 22:
      Question: I'd like to buy 50 Facebook shares with a limit order, setting a purchase price of $300 per share.
      Answer: ['Amount': '300', 'Quantity';'50']
    
    Example 22:
      Question: I'd like to buy 50 Facebook shares with a limit order, setting a purchase price of $300 per share.
      Answer: ['Amount': 300', 'Quantity': '50']
    
    Example 23:
      Question: I want to initiate a limit order to sell 100 Google stocks, specifying a selling price of $2,800 per share.
      Answer: ['Amount': '2800', 'Quantity': '100']
    
    Example 24:
      Question: Purchasing 400 Microsoft shares with a market order, prioritizing a swift execution of the purchase.
      Answer: ['Amount': '0', "Quantity": '400']
    
    Example 25:
      Question: Placing a limit order to buy 200 IBM shares, aiming to purchase them at a price not exceeding $120 per share.
      Answer: ['Amount': '120', 'Quantity': '200']
      
    Example 26:
      Question: I am looking to sell 150 Tesla shares using a market order, ensuring a quick execution of the sell order.
      Answer: ['Amount': '0', 'Quantity': '150']
    
    Example 27:
      Question: I'd like to buy 250 Netflix shares with a limit order, setting a purchase price of $450 per share.
      Answer: ['Amount': '450', 'Quantity': '250']
    
    Example 28:
      Question: Selling 100 Amazon shares using a market order to ensure a quick execution of the sell order.
      Answer: ['Amount': '0', 'Quantity': '100'
    
    Example 29:
      Question: I want to place a limit order for 60 Nvidia shares, aiming to purchase them at a price not exceeding $400 per share.
      Answer: ['Amount': '400', 'Quantity': '60']
    
    Example 30:
      Question: Placing a market order to buy 300 Intel shares promptly, without specifying a particular buying price
      Answer: ['Amount': '0', 'Quantity': '300']
    """,)


security_prompt = PromptTemplate(
    input_variables=["question"], template="""
    Instructions:
    
    Answer the question in a respective format based on the context below. If the question cannot be answered using the information provided answer with "NULL" within the below specified format.
    Please recheck the output's format and attribute value before answering, strictly follow the format
    
    Answer Format: ['Security': string']

    Context: You are an assitant who tries to answer from financial perspective by extracting relavant information within the question sentence. You job is to identify the stock/share/ security name in the user question. 
    If you are unable to identify the relevant information answer with "NULL" for the fields mentioned in the format.
    
    Question: {question}
    
    Please understand on how to answer from below examples.
      
    Example 1:
      Question: I am looking to place a limit order for hundred shares of Amazon, aiming to purchase them at a price not exceeding $3,000 per share
      Answer: ['Security': 'Amazon']
    
    Example 2:
      Question: Placing a market order to sell 200 Apple shares immediately, regardless of the current market price.
      Answer: ['Security': 'Apple']

    Example 3:
      Question: I'd like to initiate a limit order for 50 Google stocks, specifying a buying price of $2,500 per share.
      Answer: ['Security': 'Google']
    
    Example 4:
      Question: Selling 500 Microsoft shares using a market order to ensure a quick execution of the sell order.
      Answer: ['Security': Microsoft']
    
    Example 5:
      Question: I want to buy 150 Tesla shares with a limit order, setting a purchase price of seven hundred per. share.
      Answer: ['Security': 'Tesla']
    
    Example 6:
      Question: Placing a market order to sell 300 Facebook shares promptly, without specifying a particular selling price.
      Answer: ['Security': 'Facebook']
    
    Example 7:
      Question: Interested in purchasing 1,000 Nvidia shares at the current market price, executing the order immediately.
      Answer: ['Security': Nvidia']

    Example 8:
      Question: I am initiating a limit order to sell 75 Netflix shares, specifying a selling price of $550 per share.
      Answer: ['Security': 'Netflix']
    
    Example 9:
      Question: Buying 200 Amazon shares with a market order, prioritizing a swift execution of the purchase.
      Answer: ['Security': 'Amazon"]
    
    Example 10:
      Question: I want to place a limit order for 120 shares, aiming to buy them at a price not exceeding $50 per share.
      Answer: ['Security': 'NULL']
    
    Example 11:
      Question: Placing a market order to sell 400 IBM shares promptly, without setting a specific selling price.
      Answer: ['Security': 'IBM']
    
    Example 12:
      Question: I'd like to buy 80 Apple shares using a limit order, setting a purchase price of $150 per share.
      Answer: ['Security': 'Apple']
    
    Example 13:
      Question: Selling 250 shares with a market order, ensuring a quick execution of the sell order.
      Answer: ['Security': 'NULL']
    
    Example 14:
      Question: I am interested in purchasing 300 Google stocks at the current market price, executing the order immediately.
      Answer: ['Security': 'Google']
    
    Example 15:
      Question: Placing a limit order to sell 50 Microsoft shares, specifying a selling price of $250 per share.
      Answer: ['Security': 'Microsoft']

    Example 16:
      Question: I want to place a market order to buy 100 Netflix shares promptly, without specifying a particular buying price.
      Answer: ['Security': 'Netflix']
      
    Example 17:
      Question: Buying 150 Tesla shares with a limit order, setting a purchase price of $800 per share.
      Answer: ['Security': 'Tesla']
      
    Example 18:
      Question: Initiating a market order to sell 200 Nvidia shares immediately, regardless of the current market price.
      Answer: ['Security': 'Nvidia']
      
    Example 19:
      Question: I am looking to place a limit order for 80 Amazon shares, aiming to purchase them at a price not exceeding $3,500 per share.
      Answer: ['Security': 'Amazon']
      
    Example 20:
      Question: Placing a market order to sell 120 Intel shares promptly, without setting a specific selling price.
      Answer: ['Security': 'Intel']

    Example 21:
      Question: Selling 300 Apple shares using a market order to ensure a quick execution of the sell order.
      Answer: ['Security': 'Apple']
    
    Example 22:
      Question: I'd like to buy 50 Facebook shares with a limit order, setting a purchase price of $300 per share.
      Answer: ['Security!: 'Facebook']
    
    Example 23:
      Question: I want to initiate a limit order to sell 100 Google stocks, specifying a selling price of $2,800 per share.
      Answer: ['Security': Google']
    
    Example 24:
      Question: Purchasing 400 Microsoft shares with a market order, prioritizing a swift execution of the purchase.
      Answer: ['Security': 'Microsoft']

    Example 25:
    Question: Placing a limit order to buy 200 shares, aiming to purchase them at a price not exceeding $120 per share.
    Answer: ['Security': 'NULL']

    Example 26:
    Question: I am looking to sell 150 Tesla shares using a market order, ensuring a quick execution of the sell order.
    Answer: ['Security'; 'Tesla']
""")        



market_prompt = PromptTemplate(
    input_variables=["question"], template=""" 
    Instructions:

    Answer the question in a respective format based on the context below. If the question cannot be answered using the information provided answer with "NULL" within the below specified format.
    Please recheck the output's format and attribute value before answering, strictly follow the format
    
    Answer Format: ['Action': 'string', 'Order Type': 'string']

    Context: You are an assitant who tries to answer from financial perspective by extracting relavant information within the question sentence. 
    Your job is to identify the action and order type for an trade market order. Action in an order means if its a Buy or Sell order. 
    Order Type mean is its a Market order or Limit Order. Market orders are immediate orders traded at market price where as Limit orders re orders which be placed only when the market prices reaches a mentioned limit. 
    Your job is to identify both Action and Order Type in the user question. If you are unable to identify the relevant information answer with "NULL" for the fields mentioned in the format.

    Question: {question}

    Please understand on how to answer from below examples

    Example 1:
      Question: I am looking to place a limit order for hundred shares of Amazon, aiming to purchase them at a price not exceeding $3,000 per share.
      Answer: ['Action': 'Buy', 'Order Type': 'Limit']

    Example 2:
      Question: Placing a market order to sell 200 Apple shares immediately, regardless of the current market price.
      Answer: ['Action': 'Sell', 'Order Type': 'Market']

    Example 3:
      Question: I'd like to initiate a limit order for 50 Google stocks, specifying a buying price of $2,500 per share.
      Answer: ['Action': 'Buy', 'Order Type': 'Limit']
    
    Example 4:
      Question: Selling 500 Microsoft shares using a market order to ensure a quick execution of the sell order
      Answer: ['Action': 'Sell', 'Order Type': 'Market']
    
    Example 5:
      Question: I want to buy 150 Tesla shares with a limit order, setting a purchase price of seven hundred per share.
      Answer: ['Action': 'Buy', 'Order Type": 'Limit']
    
    Example 6:
      Question: Placing a market order to sell 300 Facebook shares promptly, without specifying a particular selling price.
      Answer: ['Action': 'Sell', 'Order Type: 'Market' j
      
    Example 7:
      Question: Interested in purchasing 1,000 Nvidia shares at the current market price, executing the order immediately.
      Answer: ['Action': 'Buy', 'Order Type': 'Market']

    Example 8:
      Question: I am initiating a limit order to sell 75 Netflix shares, specifying a selling price of $550 per share.
      Answer: ['Action': 'Sell', 'Order Type': 'Limit']
    
    Example 9:
      Question: Buying 200 Amazon shares with a market order, prioritizing a swift execution of the purchase.
      Answer: ['Action': 'Buy', 'Order Type': 'Market']
    
    Example 10:
      Question: I want to place a limit order for 120 shares, aiming to buy them at a price not exceeding $50 per share.
      Answer: ['Action': 'Buy', 'Order Type': "Limit']
      
    Example 11:
      Question: Placing a market order to sell 400 IBM shares promptly, without setting a specific selling price.
      Answer: [Action': 'Sell', 'Order Type': Market']
      
    Example 12:
      Question: I'd like to buy 80 Apple shares using a limit order, setting a purchase price of $150 per share.
      Answer: ['Action": 'Buy', 'Order Type': 'Limit']
      
    Example 13:
      Question: Selling 250 shares with a market order, ensuring a quick execution of the sell order.
      Answer: ['Action': 'Sell', 'Order Type': 'Market']
      
    Example 14:
      Question: I am interested in purchasing 300 Google stocks at the current market price, executing the order immediately.
      Answer: ['Action': 'Buy', 'Order Type: 'Market']
      
    Example 15:
      Question: Placing a limit order to sell 50 Microsoft shares, specifying a selling price of $250 per share.
      Answer: ['Action': 'Sell', 'Order Type': 'Limit']
      
    Example 16:
      Question: I want to place a market order to buy 100 Netflix shares promptly, without specifying a particular buying price.
      Answer: ['Action': 'Buy', 'Order Type': 'Market']

    Example 17:
      Question: Buying 150 Tesla shares with a limit order, setting a purchase price of $800 per share.
      Answer: ['Action': 'Buy', 'Order Type: 'Limit'j
    
    Example 18:
      Question: Initiating a market order to sell 200 Nvidia shares immediatèly, regardless of the current market price.
      Answer: ['Action': 'Sell', 'Order Type: 'Market']

    Example 19:
      Question: I am looking to place a limit order for 80 Amazon shares, aiming to purchase them at a price not exceeding $3,500 per share.
      Answer: ['Action': 'Buy', 'Order Type': 'Limit']

    Example 20:
      Question: Placing an order to sell 120 Intel shares promptly, without setting a specific selling price.
      Answer: ['Action': 'Sell', 'Order Type: 'NULL']

    Example 21:
      Question: Selling 300 Apple shares using a market order to ensure a quick execution of the sell order.
      Answer: ['Action': 'Sell', 'Order Type': 'Market']

    Example 22:
      Question: I'd like to buy 50 Facebook shares with a limit order, setting a purchase price of $300 per share.
      Answer: ['Action': 'Buy', 'Order Type': 'Limit']
    
    Example 23:
      Question: I want to initiate a limit order for 100 Google stocks, specifying a selling price of $2,800 per share.
      Answer: ['Action": 'NULL', 'Order Type': 'Limit']
    
    Example 24:
      Question: Purchasing 400 Microsoft shares with a market order, prioritizing a swift execution of the purchase.
      Answer: ['Action': 'Buy', 'Order Type': Market']

    Example 25:
      Question: Placing a limit order to buy 200 shares, aiming to purchase them at a price not exceeding $120 per Share.
      Answer: ['Action': 'Buy', 'Order Type': 'Limit']
    
    Example 26:
      Question: I am looking to sell 150 Tesla shares using a market order, ensuring a quick execution of the sell order.
      Answer: ['Action': 'Sell', 'Order Type': 'Market']

    """)
              

missing_prompt = PromptTemplate(
    input_variables=["question"], template = """
    You are a chatbot having a conversation with a human regarding the market order. Your basic responsibility is to ask the information from the human with financial and professional statements.

    Context: You will be given with only 5 types of questions. you need to first identify the question type and then get information from the human. Below are the five question types. 
    Always reply back to the human with the rules mentioned below respectively for each question

    Question Type 1: Security Name or Stock Name or Share Name missing
    Response: What is the stock name or security name

    Question Type 2: Amount is missing
    Response: What is t or price or dollar of stocks/shares

    Question Type 3: Quantity is missing
    Response: How many/much Quantity of stocks/shares are required

    Question Type 4: Action is missing
    Response: Is it a Buy Order or Sell Order

    Question Type 5: Order Type is missing
    Response: Is it a Market order or Limit Order

    But your task is to be creative in modifying the response and asking the human with professional tone

    question: {question} ?
    Response: Use professional terms and creativity here to make the response more professional and complete with amtmost 2 sentences explaining why you need
""",)              


validation_prompt = PromptTemplate(
    input_variables=["question1", "question2"], template="""
    Instructions:
    
    Answer the question in a respective format based on the context below. If the question cannot be answered using the information provided answer with "NULL" within the below specified format.
    Please recheck the output's format and attribute value before answering, strictly follow the format
    
    Question Format: ['string', 'string']
    Answer Format: ['Answer': 'string']

    Context: You are an assitant who tries to identify entities and answer from financial perspective by extracting relavant information within the question sentence. First sentence in a question tells about entity field. 
    Your job is to identify if second statement has value for the enitity present in first statement. If you can't value for entity answer with NULL. 
    Make use of entity dictionary and datatypes present below and answer the entity word
    
    [Entities Rules]: Rules to properly identify the entity values
    Stock Name: (string) identify if the second sentence has stock/share/security name which can be traded in market
    Quantity: (integer) identify if the second sentence has numerical value to quantify or measure the number of stocks or shares
    Price: (integer) identify if the second sentence has numerical value to quantify or measure the price or amount of trade order, it can have dollars 
    Buy/Sell: (string) identify if the second sentence has either Buy or Sell words or any related words for Buy/Sell 
    Market/Limit: (string) identify if the second sentence has either Market or Limit words or any related words to them
    [/Entities]


    Question: [{question1}, {question2}]
    Before answering check datatypes of respective fields

    Please understand on how to answer the question from below example answers

    Example 1:
      Question: ['Stock Name', 'Apple Stocks']
      Answer: ['Stock Name': 'Apple']

    Example 2:
      Question: ['Stock Name', 'I want to buy Tesla Stocks']
      Answer: ['Stock Name': 'Tesla']

    Example 3:
      Question: ['Stock Name', 'Sell my Google shares']
      Answer: ['Stock Name': 'Google']
      
    Example 4:
      Question: ['Stock Name', 'Buy IBM']
      Answer: ['Stock Name': 'IBM']

    Example 5:
      Question: ['Quantity', 'I want to buy 100 shares']
      Answer: ['Quantity': '100']

    Example 6:
      Question: ['Quantity', 'sell 320 stocks']
      Answer: ['Quantity': '320']

    Example 7:
      Question: ['Quantity', 'sell two million stocks']
      Answer: ['Answer': '2000000']

    Example 8:
      Question: ['Buy/Sell', 'Buy order']
      Answer: ['Buy/Sell': 'Buy']

    Example 9:
      Question: ['Buy/Sell', 'I wanted to Buy']
      Answer: ['Buy/Sell': 'Buy']

    Example 10:
      Question: ['Buy/Sell', 'i want to sell']
      Answer: ['Buy/Sell': 'Sell']

    Example 11:
      Question: ['Buy/Sell', Sell Order']
      Answer: ['Buy/Sel1': 'Sell'']

    Example 12:
      Question: ['Market/Limit', 'Place a market order']
      Answer: ['Market/Limit: 'Market']

    Example 13:
      Question: ['Market/Limit', 'I wanted for a limit order']
      Answer: ['Market/Limit': 'Limit']

      """,)




def ner (x):
  return {i.split(':')[0]:i.split(':')[1] for i in x.replace(" ",'').replace("'","").replace("[","").replace("]","").split(",")}


def report(data):
  time.sleep(1)
  random_number = random.randint(1, 20)
  df = pd.DataFrame([["Initials","KPMAKLG"], ['Account Number', "16003489_4356"], ['Security', data['Security']], 
                     ['Amount', '$'+data['Amount']], ['Quantity',data['Quantity']], ['Action',data['Action']], 
                     ['OrderType', data['OrderType']]], columns=['Attributes', 'Details']).set_index('Attributes')
  return df, random_number


def dict_merge(dicts):
  return {j:i[j] for i in dicts for j in i.keys()}


def resolve():
   st.session_state.socket = st.session_state.LLM_pipe[0]
   var = st.session_state.LLM_pipe[0]
   return conversation_chain.invoke ({"question": var}).content


def validate_LLM(text):
   mapper = {"Action": "Buy/Sell",
            "Order Type": "Market/Limit",
            "Amount": "Price",
            "Security": "Stock Name",
            "Quantity": "Quantity"} 
   rev_mapper = {mapper[i]:i for i in mapper.keys()}
   reply = validation_chain.invoke({"question1": mapper[st.session_state.socket.split(" ")[0]], "question2": text}).content
   i = reply.replace("'","").replace(" ","").split("[")[1].split("]")[0]
   reply = {i.split(':')[0] : i.split(':')[1]}
   if reply[i.split(':')[0]]=="NULL":
      return [201, resolve()]
   else:
      if len(st.session_state.LLM_pipe) == 1:
         st.session_state.LLM_data[rev_mapper[i.split(':')[0].replace("StockName","Stock Name")]] = i.split(':')[1]
         return [200, report(st.session_state.LLM_data)]
      
      st.session_state.LLM_data[rev_mapper[i.split(':')[0]]] = i.split(':')[1]
      st.session_state.LLM_pipe = st.session_state.LLM_pipe[1:]
      st.session_state.socket = st.session_state.LLM_pipe[0]
      reply = [201, resolve]
      return reply
   

def intial_LLM(query):
  st.session_state.LLM_data = {}
  st.session_state.LLM_pipe = []
  st.session_state.socket = []

  sec = ner(sec_chain.invoke({"question": query}).content)
  order = ner(order_chain.invoke ({"question": query}).content)
  market = ner(market_chain.invoke ({"question": query}).content)
  data = dict_merge ([sec, order, market])

  pipe = []

  if data['Amount']=='0' and data['Quantity']=='0':
    pipe.append("Quantity is 0")
  if data['Security']=="NULL":
    pipe.append("Security is NULL")
  if data['Action'] == 'NULL':
    pipe.append("Action is NULL")
  if data['OrderType']=='NULL':
    pipe.append("OrderType is NULL")
  
  if pipe==[]:
    return [200, data]
  else:
    st.session_state.LLM_data = data
    st.session_state.LLM_pipe = pipe
    return [201, resolve()]
  

def transcribe():
  url = 'http://127.0.0.1:5000/transcribe'
  data = {'filename': 'data/voice.mp3'}
  response = json.loads(requests.post(url, json=data).text)['predictions']
  return response
   
st.set_page_config(
    page_title="SPARK-4-IO",
    page_icon="💬",
)

st.title("💬 SPARK 4 IO")
st.caption("🚀 Smart Personal Assistant for Realtime Knowledge")

if "openai_model" not in st.session_state:
  st.session_state["openai_model"] = "gpt-3.5-turbo"

if "messages" not in st.session_state:
  st.session_state.messages = []

if "LLM_data" not in st.session_state:
  st.session_state.LLM_data = {}

if "LLM_pipe" not in st.session_state:
  st.session_state.LLM_pipe = []

if "socket" not in st.session_state:
  st.session_state.socket = ""

if "model" not in st.session_state:
   st.session_state.model = ChatOpenAI(temperature=0, openai_api_key=pkey)

if "transcribe_state" not in st.session_state:
  st.session_state.transcribe_state = 0


with st.sidebar:
    st.markdown("![Foo](https://www.capitalgroup.com/content/experience-fragments/site_headers_and_navigation_menus/advisor/header/master/_jcr_content/root/headernavigation/logo.coreimg.svg/1673462595344/logos-cg-af-advisor-01.svg)")
    st.markdown("# About")
    st.markdown("The Assistant helps Managers in placing COMET orders and estimates Time to Desk in real-time.")


# Display All messages on Re-run      
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

llm = st.session_state.model

sec_chain = security_prompt | llm
order_chain = price_prompt | llm
market_chain = market_prompt | llm
conversation_chain = missing_prompt | llm
validation_chain = validation_prompt | llm

with stylable_container(
        key="bottom_content",
        css_styles="""
            {
                position: fixed;
                bottom: 120px;
            }
            """,
    ):
    col0, col1, col2 = st.columns([18,1,1])
    with col2:
      audio = audio_recorder(text="", recording_color="#faae41", neutral_color="#555867", 
                             icon_name="microphone-lines", icon_size="2x", sample_rate=41_000, key="recorder")
    with col1:
      if audio is not None and len(audio)!=st.session_state.transcribe_state:
        with open("data/voice.mp3","wb") as f:
          f.write(audio)
        with st.spinner(""):
          speech = transcribe()
          st.session_state.transcribe_state = len(audio)
          js = f"""
              <script>
                  function insertText(dummy_var_to_force_repeat_execution) {{
                      var chatInput = parent.document.querySelector('textarea[data-testid="stChatInput"]');
                      var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
                      nativeInputValueSetter.call(chatInput, "{speech}");
                      var event = new Event('input', {{ bubbles: true}});
                      chatInput.dispatchEvent(event);
                  }}
                  insertText(1);
              </script>
              """
          st.components.v1.html(js, height=0)


if prompt := st.chat_input("Place an Order?"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""
        stream_response = ""
        if len(st.session_state.socket)>0:
            intermediate_replies = validate_LLM(prompt)
            if intermediate_replies[0]==200:
              frame = intermediate_replies[1][0]
              ttd = intermediate_replies[1][1]
              message_placeholder.markdown("**Order Summary**")
              st.dataframe(frame)
              st.markdown("The Estimated :red[Time to Desk 🕐] for the order to execute is around :red["+str(ttd)+" mins].")
              st.warning("Order will trigger Ownership Compliance")
              st.button("🔗 Route Smartly", type="secondary")          
            else:
              full_response += intermediate_replies[1]
              for chunk in full_response.split():
                stream_response += chunk + " "
                time.sleep(0.05)
                message_placeholder.markdown(stream_response + "▌")
              message_placeholder.markdown(stream_response)
        else:
          ai_prompt = [intial_LLM(prompt)]
          for response in ai_prompt:
            if response[0]==200:
              frame, ttd = report(response[1])
              message_placeholder.markdown("**Order Summary**")
              st.dataframe(frame)
              st.markdown("The Estimated :red[Time to Desk] for the order to execute is around :red["+str(ttd)+" mins].")
              st.warning("Order will trigger Ownership Compliance")
              st.button("Route Smartly", type="secondary")
            else:
              full_response += str(response[1])
              message_placeholder.markdown(full_response)
    st.session_state.messages.append({"role": "assistant", "content": full_response})

examples = [
  "Initiating a market order to sell Apple shares immediately, regardless of the current market price.",
  "I'd like to buy 120 Google shares with a limit order, setting a purchase price of 52,200 per share.",
  "Placing a limit order to sell 150 Microsoft shares, specifying a selling price of $300 per share.",
  "Selling 250 Tesla shares using a market order to ensure a quick execution of the sell order.",
  "I want to place a market order to buy 200 Amazon shares promptly, without specifying a particular buying price.",
  "Interested in purchasing 100 Nvidia Shares at the current market price, executing the order immediately.",
  "Placing a limit order to sell 50 Facebook shares, aiming for a selling price of $400 per share.",
  "I am looking to sell 200 IBM shares with a market order, ensuring a swift execution of the sell order.",
  "Buying 80 Netflix shares using a limit order, setting a purchase price of $600 per share.",
  "I'd like to initiate a market order to buy 300 Intel shares promptly, without specifying a particular buying price.",
  "Placing a limit order to sell 120 Amazon shares, specifying a selling price of $3,000 per share.",
  "I want to place a market order to buy 70 Microsoft shares immediately, regardless of the current market price.",
  "Selling 100 Facebook shares with a limit order, aiming for a selling price of $250 per.share.",
  "I am interested in purchasing 150 Google stocks at the current market price, executing the order immediately.",
  "Placing a market order to sell 60 Nvidia shares promptly, without setting a specific selling price."]